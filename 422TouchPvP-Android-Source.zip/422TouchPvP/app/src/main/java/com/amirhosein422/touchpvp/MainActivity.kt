package com.amirhosein422.touchpvp

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("touchpvp", Context.MODE_PRIVATE) }
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun render() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(0xFF151922.toInt())
        }
        val title = TextView(this).apply {
            text = "422 Touch PvP"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        outer.addView(title, LinearLayout.LayoutParams(-1, dp(54)))
        val subtitle = TextView(this).apply {
            text = "دکمه‌های شناور برای ماینکرفت Bedrock"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFCAD1DE.toInt())
        }
        outer.addView(subtitle, LinearLayout.LayoutParams(-1, dp(40)))

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFFFD166.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        outer.addView(status, LinearLayout.LayoutParams(-1, dp(56)))

        addLabel(outer, "تعداد لمس با هر بار فشردن")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("۱ بار", "۲ بار", "۳ بار"))
        spinner.setSelection((prefs.getInt("clicks", 1) - 1).coerceIn(0, 2))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                prefs.edit().putInt("clicks", position + 1).apply()
            }
        }
        outer.addView(spinner, LinearLayout.LayoutParams(-1, dp(48)))

        val hold = CheckBox(this).apply {
            text = "حالت نگه‌داشتن لمس (تا حداکثر ۱۰ ثانیه)"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            buttonTintList = android.content.res.ColorStateList.valueOf(0xFF34C759.toInt())
            isChecked = prefs.getBoolean("hold", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("hold", checked).apply() }
        }
        outer.addView(hold, LinearLayout.LayoutParams(-1, dp(54)))

        addLabel(outer, "اندازه دکمه‌ها")
        val sizeText = TextView(this).apply {
            text = "اندازه: ${prefs.getInt("size", 56)}"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
        }
        outer.addView(sizeText)
        val seek = SeekBar(this).apply {
            max = 68
            progress = (prefs.getInt("size", 56) - 32).coerceIn(0, 68)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + 32
                    sizeText.text = "اندازه: $value"
                    prefs.edit().putInt("size", value).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        outer.addView(seek, LinearLayout.LayoutParams(-1, dp(42)))

        val start = makeButton("نمایش دکمه‌های شناور", 0xFF218B50.toInt())
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
                Toast.makeText(this, "مجوز نمایش روی برنامه‌های دیگر را فعال کن و برگرد.", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, OverlayService::class.java))
                updateStatus()
            }
        }
        outer.addView(start, LinearLayout.LayoutParams(-1, dp(52)))

        val accessibility = makeButton("فعال‌کردن مجوز لمس اندروید", 0xFF315A91.toInt())
        accessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        outer.addView(accessibility, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })

        val stop = makeButton("بستن دکمه‌های شناور", 0xFF9E3434.toInt())
        stop.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            updateStatus()
        }
        outer.addView(stop, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })

        val note = TextView(this).apply {
            text = "نکته: مجوز دسترس‌پذیری فقط در صورت اعتماد به برنامه فعال شود. لمس‌ها با محدودیت‌های اندروید انجام می‌شوند و ممکن است در بعضی بازی‌ها یا سرورها کار نکنند."
            textSize = 13f
            setTextColor(0xFFB9C1CE.toInt())
            setPadding(0, dp(18), 0, 0)
        }
        outer.addView(note, LinearLayout.LayoutParams(-1, -2))
        val scroll = ScrollView(this).apply { addView(outer) }
        setContentView(scroll)
        updateStatus()
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(12), 0, dp(4))
        })
    }

    private fun makeButton(text: String, color: Int) = Button(this).apply {
        this.text = text
        setTextColor(0xFFFFFFFF.toInt())
        backgroundTintList = android.content.res.ColorStateList.valueOf(color)
    }

    private fun updateStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val service = TapAccessibilityService.instance != null
        status.text = "مجوز شناور: ${if (overlay) "فعال" else "خاموش"} | سرویس لمس: ${if (service) "فعال" else "خاموش"}"
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }
}
