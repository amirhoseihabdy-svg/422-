package com.amirhosein422.touchpvp

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val items = mutableListOf<PairViews>()
    private lateinit var toolbar: LinearLayout
    private var editMode = true
    private val prefs by lazy { getSharedPreferences("touchpvp", Context.MODE_PRIVATE) }

    data class PairViews(
        val number: Int,
        val target: TextView,
        val trigger: TextView,
        val targetParams: WindowManager.LayoutParams,
        val triggerParams: WindowManager.LayoutParams
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "مجوز نمایش شناور فعال نیست.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createToolbar()
        addPair()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun params(x: Int, y: Int, size: Int) = WindowManager.LayoutParams(
        size, size, overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun circle(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(dp(2), Color.WHITE)
    }

    private fun label(number: Int, color: Int): TextView = TextView(this).apply {
        text = number.toString()
        textSize = 18f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = circle(color)
        elevation = dp(5).toFloat()
    }

    private fun createToolbar() {
        toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = GradientDrawable().apply {
                setColor(0xEE202630.toInt())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0xFF8993A5.toInt())
            }
        }
        val plus = toolButton("+") { addPair() }
        val minus = toolButton("−") { removeLastPair() }
        val move = toolButton(if (editMode) "جابجایی: روشن" else "جابجایی: خاموش") {
            editMode = !editMode
            (it as TextView).text = if (editMode) "جابجایی: روشن" else "جابجایی: خاموش"
            Toast.makeText(this, if (editMode) "دکمه‌ها را بکش تا جابه‌جا شوند." else "حالت اجرا فعال شد.", Toast.LENGTH_SHORT).show()
        }
        toolbar.addView(plus, LinearLayout.LayoutParams(dp(44), dp(44)))
        toolbar.addView(minus, LinearLayout.LayoutParams(dp(44), dp(44)))
        toolbar.addView(move, LinearLayout.LayoutParams(dp(118), dp(44)))
        val p = params(dp(8), dp(70), WindowManager.LayoutParams.WRAP_CONTENT)
        p.width = WindowManager.LayoutParams.WRAP_CONTENT
        p.height = WindowManager.LayoutParams.WRAP_CONTENT
        wm.addView(toolbar, p)
        attachDrag(toolbar, p, null)
    }

    private fun toolButton(text: String, action: (View) -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setOnClickListener(action)
    }

    private fun addPair() {
        if (items.size >= 10) {
            Toast.makeText(this, "حداکثر ۱۰ جفت دکمه مجاز است.", Toast.LENGTH_SHORT).show()
            return
        }
        val n = (items.maxOfOrNull { it.number } ?: 0) + 1
        val size = dp(prefs.getInt("size", 56))
        val targetX = dp(190 + ((n - 1) % 3) * 12)
        val targetY = dp(230 + ((n - 1) / 3) * 72)
        val triggerX = dp(24)
        val triggerY = dp(230 + ((n - 1) / 3) * 72)
        val red = label(n, 0xFFE53935.toInt())
        val green = label(n, 0xFF20A653.toInt())
        val rp = params(targetX, targetY, size)
        val gp = params(triggerX, triggerY, size)
        wm.addView(red, rp)
        wm.addView(green, gp)
        val pair = PairViews(n, red, green, rp, gp)
        items.add(pair)
        attachDrag(red, rp, pair)
        attachDrag(green, gp, pair)
        green.setOnClickListener {
            if (editMode) {
                Toast.makeText(this, "برای لمس واقعی، حالت جابجایی را خاموش کن.", Toast.LENGTH_SHORT).show()
            } else {
                performConfiguredTap(pair)
            }
        }
        Toast.makeText(this, "جفت شماره $n اضافه شد.", Toast.LENGTH_SHORT).show()
    }

    private fun removeLastPair() {
        if (items.isEmpty()) return
        val p = items.removeAt(items.lastIndex)
        runCatching { wm.removeView(p.target) }
        runCatching { wm.removeView(p.trigger) }
    }

    private fun attachDrag(view: View, lp: WindowManager.LayoutParams, pair: PairViews?) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = event.rawX; downY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) moved = true
                    if (editMode && moved) {
                        lp.x = (startX + dx).coerceAtLeast(0)
                        lp.y = (startY + dy).coerceAtLeast(0)
                        runCatching { wm.updateViewLayout(v, lp) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (pair != null && !editMode && !moved && v === pair.trigger) performConfiguredTap(pair)
                    true
                }
                else -> true
            }
        }
    }

    private fun performConfiguredTap(pair: PairViews) {
        val service = TapAccessibilityService.instance
        if (service == null) {
            Toast.makeText(this, "اول در تنظیمات اندروید، مجوز لمس دسترس‌پذیری را فعال کن.", Toast.LENGTH_LONG).show()
            return
        }
        val location = IntArray(2)
        pair.target.getLocationOnScreen(location)
        val x = location[0] + pair.target.width / 2f
        val y = location[1] + pair.target.height / 2f
        if (prefs.getBoolean("hold", false)) {
            service.hold(x, y, 10000L)
        } else {
            val count = prefs.getInt("clicks", 1).coerceIn(1, 3)
            for (i in 0 until count) {
                android.os.Handler(mainLooper).postDelayed({
                    TapAccessibilityService.instance?.tap(x, y, 60L)
                }, i * 120L)
            }
        }
    }

    override fun onDestroy() {
        runCatching { items.forEach { wm.removeView(it.target); wm.removeView(it.trigger) } }
        items.clear()
        runCatching { wm.removeView(toolbar) }
        super.onDestroy()
    }
}
